// 1) Почта единственного администратора (только с неё можно редактировать сайт)
export const ADMIN_EMAIL = "ВАША_ПОЧТА@gmail.com";

// 2) Данные вашего Firebase-проекта (Project settings → Your apps → Web app → Config)
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_APP_ID"
};
