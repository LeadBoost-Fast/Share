import { firebaseConfig, ADMIN_EMAIL } from "./firebase-config.js";

const FALLBACK_BASE = "https://mir-flowers-aktau.vercel.app/";
const WA_TEXT = "Здравствуйте! Хочу заказать букет 💐 Повод: , бюджет: , доставка куда и к какому времени: ";

const DEFAULTS = {
  rosePrice: 250,
  whatsapp: "77771027292",
  phones: ["+7 777 102 72 92", "+7 706 707 36 22"],
  instagram: "mir_flowers_aktau",
  priceRows: [
    { qty: 25, roses: "6 250 ₸", decorated: "8 250 ₸" },
    { qty: 51, roses: "12 750 ₸", decorated: "15 500 ₸" },
    { qty: 101, roses: "25 250 ₸", decorated: "28 250 ₸" },
    { qty: 151, roses: "37 750 ₸", decorated: "—" },
    { qty: 201, roses: "—", decorated: "52 250 ₸" }
  ],
  gallery: [
    { emoji: "💗", caption: "Шикарные розы — 250 ₸/шт", img: "img/cream-roses.jpg" },
    { emoji: "🐑", caption: "Нежный букет с игрушкой", img: "img/toy-bouquet.jpg" },
    { emoji: "🌹", caption: "Вечная классика — красные розы", img: "img/red-roses.jpg" },
    { emoji: "⭐", caption: "Новый тренд: букеты с милыми игрушками", img: "img/trend-toys.jpg" },
    { emoji: "🎀", caption: "Большой букет в розовом оформлении", img: "img/big-pink.jpg" },
    { emoji: "🌸", caption: "Розовые розы", img: "img/pink-roses.jpg" },
    { emoji: "🤍", caption: "«Когда он знает, как сделать тебя счастливой»", img: "img/for-her.jpg" }
  ]
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const clone = (o) => JSON.parse(JSON.stringify(o));

let content = clone(DEFAULTS);
let fb = null;        // { db, auth, doc, setDoc, ... } — только если Firebase настроен
let isAdmin = false;

// Если картинки нет в папке img/ — берём её с исходного сайта
document.addEventListener("error", (e) => {
  const t = e.target;
  if (t.tagName === "IMG" && !t.dataset.tried && !/^https?:/.test(t.getAttribute("src") || "")) {
    t.dataset.tried = "1";
    t.src = FALLBACK_BASE + t.getAttribute("src");
  }
}, true);

function render() {
  const price = Number(content.rosePrice) || 0;
  $$("[data-bind=rosePrice]").forEach((el) => (el.textContent = price.toLocaleString("ru-RU")));
  $$("[data-bind=instagram]").forEach((el) => (el.textContent = content.instagram));

  const wa = "https://wa.me/" + String(content.whatsapp).replace(/\D/g, "") + "?text=" + encodeURIComponent(WA_TEXT);
  $$("[data-wa]").forEach((a) => (a.href = wa));
  $$("[data-ig]").forEach((a) => (a.href = "https://instagram.com/" + content.instagram));

  $("#priceRows").innerHTML = content.priceRows
    .map((r) => `<tr><td><b>${esc(r.qty)}</b> шт</td><td>${esc(r.roses)}</td><td>${esc(r.decorated)}</td></tr>`)
    .join("");

  $("#gallery").innerHTML = content.gallery
    .map((g) => `<figure><span class="em">${esc(g.emoji)}</span><img src="${esc(g.img)}" alt="${esc(g.caption)} — Цветы Актау, Mir Flowers" loading="lazy"><figcaption>${esc(g.caption)}</figcaption></figure>`)
    .join("");

  $("#phones").innerHTML =
    content.phones.filter(Boolean).map((p) => `<a href="tel:${esc(p.replace(/[^\d+]/g, ""))}">📞 ${esc(p)}</a>`).join("") +
    `<a data-ig href="https://instagram.com/${esc(content.instagram)}" target="_blank" rel="noopener">Instagram</a>`;
}

/* ---------- Firebase (вход админа + хранение правок) ---------- */
async function initFirebase() {
  const ok = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("PASTE");
  if (!ok) return;
  try {
    const V = "10.14.1";
    const [appM, fsM, authM] = await Promise.all([
      import(`https://www.gstatic.com/firebasejs/${V}/firebase-app.js`),
      import(`https://www.gstatic.com/firebasejs/${V}/firebase-firestore.js`),
      import(`https://www.gstatic.com/firebasejs/${V}/firebase-auth.js`)
    ]);
    const app = appM.initializeApp(firebaseConfig);
    fb = {
      db: fsM.getFirestore(app), auth: authM.getAuth(app),
      doc: fsM.doc, getDoc: fsM.getDoc, setDoc: fsM.setDoc,
      provider: new authM.GoogleAuthProvider(),
      signInWithPopup: authM.signInWithPopup, signOut: authM.signOut
    };

    // Любой посетитель читает сохранённые правки без входа
    try {
      const snap = await fb.getDoc(fb.doc(fb.db, "site", "content"));
      if (snap.exists()) { content = { ...clone(DEFAULTS), ...snap.data() }; render(); }
    } catch (e) { console.warn("Не удалось загрузить правки:", e); }

    $("#btnLogin").hidden = false;
    authM.onAuthStateChanged(fb.auth, (user) => {
      isAdmin = !!user && user.emailVerified && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      if (user && !isAdmin) { fb.signOut(fb.auth); alert("Этот аккаунт не имеет доступа к редактированию."); }
      $("#adminbar").hidden = !isAdmin;
      $("#btnLogin").hidden = isAdmin;
    });
  } catch (e) {
    console.warn("Firebase не загрузился, сайт работает в обычном режиме:", e);
  }
}

$("#btnLogin").addEventListener("click", async (e) => {
  e.preventDefault();
  try { await fb.signInWithPopup(fb.auth, fb.provider); } catch (err) { console.warn(err); }
});
$("#btnLogout").addEventListener("click", () => fb.signOut(fb.auth));
$("#btnEdit").addEventListener("click", openEditor);

/* ---------- Редактор (виден только админу) ---------- */
function rowHtml(r = {}) {
  return `<div class="ed-row"><input class="r-qty" type="number" placeholder="Кол-во" value="${esc(r.qty)}"><input class="r-roses" placeholder="Розы" value="${esc(r.roses)}"><input class="r-dec" placeholder="С оформлением" value="${esc(r.decorated)}"><button type="button" class="del">✕</button></div>`;
}
function galHtml(g = {}) {
  return `<div class="ed-row g"><input class="g-em" placeholder="😀" value="${esc(g.emoji)}"><input class="g-img" placeholder="img/photo.jpg или https://…" value="${esc(g.img)}"><input class="g-cap" placeholder="Подпись" value="${esc(g.caption)}"><button type="button" class="del">✕</button></div>`;
}

function openEditor() {
  if (!isAdmin) return;
  const c = content, m = $("#editor");
  m.hidden = false;
  m.innerHTML = `<div class="ed-box">
    <h3>✏️ Редактирование сайта</h3>
    <label>Цена одной розы, ₸<input id="e-rose" type="number" value="${esc(c.rosePrice)}"></label>
    <label>Номер WhatsApp (только цифры, например 77771027292)<input id="e-wa" value="${esc(c.whatsapp)}"></label>
    <label>Телефон 1<input id="e-p1" value="${esc(c.phones[0] || "")}"></label>
    <label>Телефон 2<input id="e-p2" value="${esc(c.phones[1] || "")}"></label>
    <label>Instagram (без @)<input id="e-ig" value="${esc(c.instagram)}"></label>
    <h4>Таблица цен</h4>
    <div id="e-rows">${c.priceRows.map(rowHtml).join("")}</div>
    <button type="button" id="e-addrow">+ строка</button>
    <h4>Фото в разделе «Наши букеты»</h4>
    <div id="e-gal">${c.gallery.map(galHtml).join("")}</div>
    <button type="button" id="e-addph">+ фото</button>
    <div class="ed-actions"><button type="button" id="e-save">Сохранить</button><button type="button" id="e-cancel">Отмена</button></div>
    <p id="e-msg"></p>
  </div>`;

  m.onclick = (e) => {
    if (e.target.classList.contains("del")) e.target.parentElement.remove();
    else if (e.target.id === "e-addrow") $("#e-rows").insertAdjacentHTML("beforeend", rowHtml());
    else if (e.target.id === "e-addph") $("#e-gal").insertAdjacentHTML("beforeend", galHtml({ emoji: "💐" }));
    else if (e.target.id === "e-cancel" || e.target === m) { m.hidden = true; m.innerHTML = ""; }
    else if (e.target.id === "e-save") save();
  };
}

async function save() {
  if (!isAdmin) return;
  const val = (s) => $(s).value.trim();
  const next = {
    rosePrice: Number(val("#e-rose")) || 0,
    whatsapp: val("#e-wa").replace(/\D/g, ""),
    phones: [val("#e-p1"), val("#e-p2")].filter(Boolean),
    instagram: val("#e-ig").replace(/^@/, ""),
    priceRows: $$("#e-rows .ed-row").map((r) => ({
      qty: Number($(".r-qty", r).value) || 0,
      roses: $(".r-roses", r).value.trim() || "—",
      decorated: $(".r-dec", r).value.trim() || "—"
    })),
    gallery: $$("#e-gal .ed-row").map((r) => ({
      emoji: $(".g-em", r).value.trim(),
      img: $(".g-img", r).value.trim(),
      caption: $(".g-cap", r).value.trim()
    })).filter((g) => g.img)
  };
  const msg = $("#e-msg");
  msg.textContent = "Сохраняю…";
  try {
    await fb.setDoc(fb.doc(fb.db, "site", "content"), next);
    content = next;
    render();
    $("#editor").hidden = true;
    $("#editor").innerHTML = "";
  } catch (e) {
    console.warn(e);
    msg.textContent = "Не удалось сохранить: проверьте правила Firestore и почту админа.";
  }
}

render();
initFirebase();
