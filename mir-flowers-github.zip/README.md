# Mir Flowers — сайт на GitHub Pages

Копия сайта https://mir-flowers-aktau.vercel.app/ для GitHub Pages.

- Посетители открывают сайт **без регистрации** и переходят в WhatsApp.
- Редактировать цены, номер WhatsApp, телефоны и фото может **только админ** (одна почта, вход через Google).

## 1. Выложить на GitHub Pages

1. Создайте репозиторий на GitHub (например `mir-flowers`), загрузите в него все файлы из этой папки.
2. Папку `img/` создайте и положите туда фото (`hero-zontik.jpg`, `cream-roses.jpg`, `toy-bouquet.jpg`, `red-roses.jpg`, `trend-toys.jpg`, `big-pink.jpg`, `pink-roses.jpg`, `for-her.jpg`).
   Пока фото нет в `img/`, сайт подтягивает их со старого сайта автоматически.
3. Settings → Pages → Source: **Deploy from a branch** → `main` / `(root)` → Save.
4. Через минуту сайт будет на `https://ВАШ_ЛОГИН.github.io/mir-flowers/`.

## 2. Включить режим админа (бесплатно, Firebase)

GitHub Pages — статический хостинг, поэтому вход и хранение правок делает Firebase.

1. https://console.firebase.google.com → **Add project**.
2. **Build → Authentication → Get started → Sign-in method → Google → Enable**.
3. Authentication → **Settings → Authorized domains → Add domain**: `ВАШ_ЛОГИН.github.io`.
4. **Build → Firestore Database → Create database** (production mode).
5. Firestore → **Rules** → вставьте содержимое `firestore.rules`, замените `ВАША_ПОЧТА@gmail.com` на почту админа → **Publish**.
6. **Project settings → Your apps → Web (`</>`)** → скопируйте config в `firebase-config.js`
   и впишите ту же почту в `ADMIN_EMAIL`.
7. Закоммитьте изменения.

## Как редактировать

Внизу сайта нажмите «Вход для админа» → войдите Google-аккаунтом админа → появится панель
«✏️ Редактировать сайт». Другие аккаунты войти в редактор не смогут: защита стоит в правилах Firestore
на сервере, а не только в браузере.

Фото в редакторе указываются путём (`img/photo.jpg`) или ссылкой `https://…`.
Новые файлы фото загружаются в папку `img/` репозитория через GitHub.
